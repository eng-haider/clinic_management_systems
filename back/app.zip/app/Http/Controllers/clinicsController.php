<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class clinicsController extends Controller
{
    //
}
